is-number
===========

A Python library to determine if something is a number.