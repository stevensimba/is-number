is-number
==========

.. image:: https://img.shields.io/v/stis-number
   :alt: PyPi

A Python library to determine if something is a number.

Installation
-------------

.. code-bloci:: bash
   
	pip install stis-number