stis-number
==========

.. image:: https://img.shields.io/v/stis-number
   :alt: PyPi

A Python library to determine if something is a number.

Installation
-------------

.. code-block:: bash
   
	pip install stis-number